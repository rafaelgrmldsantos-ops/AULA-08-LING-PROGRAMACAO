#include <stdio.h>

// ===== Funções =====

// Preenche o array (passagem por referência)
void preencherArray(int arr[], int tamanho) {
    for (int i = 0; i < tamanho; i++) {
        printf("Numero %d: ", i + 1);
        scanf("%d", &arr[i]);
    }
}

// Exibe o array (passagem por valor usando const)
void exibirArray(const int arr[], int tamanho) {
    printf("[");
    for (int i = 0; i < tamanho; i++) {
        printf("%d", arr[i]);
        if (i < tamanho - 1) {
            printf(", ");
        }
    }
    printf("]\n");
}

// Encontra o maior valor (passagem por valor)
int encontrarMaior(const int arr[], int tamanho) {
    int maior = arr[0];
    for (int i = 1; i < tamanho; i++) {
        if (arr[i] > maior) {
            maior = arr[i];
        }
    }
    return maior;
}

// Encontra o menor valor (passagem por valor)
int encontrarMenor(const int arr[], int tamanho) {
    int menor = arr[0];
    for (int i = 1; i < tamanho; i++) {
        if (arr[i] < menor) {
            menor = arr[i];
        }
    }
    return menor;
}

// Calcula a média (passagem por valor)
float calcularMedia(const int arr[], int tamanho) {
    int soma = 0;
    for (int i = 0; i < tamanho; i++) {
        soma += arr[i];
    }
    return (float)soma / tamanho;
}

// Ordena o array em ordem crescente (passagem por referência)
void ordenarArray(int arr[], int tamanho) {
    for (int i = 0; i < tamanho - 1; i++) {
        for (int j = i + 1; j < tamanho; j++) {
            if (arr[i] > arr[j]) {
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
}

// ===== Função principal =====
int main() {
    int numeros[10];

    printf("Digite 10 numeros:\n");
    preencherArray(numeros, 10);

    printf("Array original: ");
    exibirArray(numeros, 10);

    int maior = encontrarMaior(numeros, 10);
    int menor = encontrarMenor(numeros, 10);
    float media = calcularMedia(numeros, 10);

    printf("Maior valor: %d\n", maior);
    printf("Menor valor: %d\n", menor);
    printf("Media: %.2f\n", media);

    ordenarArray(numeros, 10);
    printf("Array ordenado: ");
    exibirArray(numeros, 10);

    return 0;
}
