#include <stdio.h>

#define ALUNOS 5
#define DISCIPLINAS 4
#define MEDIA_APROVACAO 6.0

// ===== Funções =====

// Inserir notas (passagem por referência)
void inserir_notas(float notas[][DISCIPLINAS]) {
    for (int i = 0; i < ALUNOS; i++) {
        printf("Aluno %d:\n", i + 1);
        for (int j = 0; j < DISCIPLINAS; j++) {
            printf("  Nota da disciplina %d: ", j + 1);
            scanf("%f", &notas[i][j]);
        }
    }
}

// Exibir matriz de notas (passagem por valor, const)
void exibir_notas(const float notas[][DISCIPLINAS]) {
    printf("\nMatriz de Notas:\n");
    printf("        ");
    for (int j = 0; j < DISCIPLINAS; j++) {
        printf("D%d     ", j + 1);
    }
    printf("\n");
    for (int i = 0; i < ALUNOS; i++) {
        printf("Aluno %d ", i + 1);
        for (int j = 0; j < DISCIPLINAS; j++) {
            printf("%-7.2f", notas[i][j]);
        }
        printf("\n");
    }
}

// Calcular média de um aluno (passagem por valor)
float calcular_media_aluno(const float notas[][DISCIPLINAS], int aluno) {
    float soma = 0;
    for (int j = 0; j < DISCIPLINAS; j++) {
        soma += notas[aluno][j];
    }
    return soma / DISCIPLINAS;
}

// Calcular média de uma disciplina (passagem por valor)
float calcular_media_disciplina(const float notas[][DISCIPLINAS], int disciplina) {
    float soma = 0;
    for (int i = 0; i < ALUNOS; i++) {
        soma += notas[i][disciplina];
    }
    return soma / ALUNOS;
}

// Exibir relatório completo (passagem por valor)
void exibir_relatorio_final(const float notas[][DISCIPLINAS]) {
    printf("\n=== RELATORIO FINAL ===\n");
    for (int i = 0; i < ALUNOS; i++) {
        float media_aluno = calcular_media_aluno(notas, i);
        printf("Aluno %d: Media = %.2f -> %s\n", i + 1, media_aluno, (media_aluno >= MEDIA_APROVACAO ? "APROVADO" : "REPROVADO"));
    }

    printf("\nMedias por disciplina:\n");
    for (int j = 0; j < DISCIPLINAS; j++) {
        float media_disc = calcular_media_disciplina(notas, j);
        printf("Disciplina %d: Media = %.2f\n", j + 1, media_disc);
    }
}

// ===== Menu =====
void exibirMenu() {
    printf("\n=== SISTEMA DE GESTAO DE NOTAS ===\n");
    printf("1. Inserir notas\n");
    printf("2. Exibir notas\n");
    printf("3. Calcular medias por aluno\n");
    printf("4. Calcular medias por disciplina\n");
    printf("5. Exibir aprovados/reprovados\n");
    printf("0. Sair\n");
}

int obterOpcao() {
    int opcao;
    printf("Opcao: ");
    scanf("%d", &opcao);
    return opcao;
}

// ===== Função principal =====
int main() {
    float notas[ALUNOS][DISCIPLINAS] = {0};
    int opcao;

    do {
        exibirMenu();
        opcao = obterOpcao();

        switch(opcao) {
            case 1:
                inserir_notas(notas);
                break;
            case 2:
                exibir_notas(notas);
                break;
            case 3:
                for (int i = 0; i < ALUNOS; i++) {
                    float media = calcular_media_aluno(notas, i);
                    printf("Aluno %d: Media = %.2f\n", i + 1, media);
                }
                break;
            case 4:
                for (int j = 0; j < DISCIPLINAS; j++) {
                    float media = calcular_media_disciplina(notas, j);
                    printf("Disciplina %d: Media = %.2f\n", j + 1, media);
                }
                break;
            case 5:
                exibir_relatorio_final(notas);
                break;
            case 0:
                printf("Encerrando...\n");
                break;
            default:
                printf("Opcao invalida!\n");
        }

    } while(opcao != 0);

    return 0;
}
