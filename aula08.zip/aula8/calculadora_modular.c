#include <stdio.h>

// ===== Funções de apoio =====

// Função para exibir o menu
void exibirMenu() {
    printf("\n=== CALCULADORA ===\n");
    printf("1. Somar\n");
    printf("2. Subtrair\n");
    printf("3. Multiplicar\n");
    printf("4. Dividir\n");
    printf("0. Sair\n");
}

// Função para obter a opção do usuário
int obterOpcao() {
    int opcao;
    printf("Opcao: ");
    scanf("%d", &opcao);
    return opcao;
}

// Função para obter dois números (passagem por referência)
void obterNumeros(float *a, float *b) {
    printf("Digite o primeiro numero: ");
    scanf("%f", a);
    printf("Digite o segundo numero: ");
    scanf("%f", b);
}

// Funções de operações matemáticas (passagem por valor)
float somar(float x, float y) {
    return x + y;
}

float subtrair(float x, float y) {
    return x - y;
}

float multiplicar(float x, float y) {
    return x * y;
}

float dividir(float x, float y) {
    if (y == 0) {
        printf("Erro: divisao por zero!\n");
        return 0;
    }
    return x / y;
}

// Função para exibir o resultado
void exibirResultado(float resultado) {
    printf("Resultado: %.2f\n", resultado);
}

// ===== Função principal =====
int main() {
    int opcao;
    float n1, n2, resultado;

    do {
        exibirMenu();
        opcao = obterOpcao();

        switch (opcao) {
            case 1:
                obterNumeros(&n1, &n2);
                resultado = somar(n1, n2);
                exibirResultado(resultado);
                break;
            case 2:
                obterNumeros(&n1, &n2);
                resultado = subtrair(n1, n2);
                exibirResultado(resultado);
                break;
            case 3:
                obterNumeros(&n1, &n2);
                resultado = multiplicar(n1, n2);
                exibirResultado(resultado);
                break;
            case 4:
                obterNumeros(&n1, &n2);
                resultado = dividir(n1, n2);
                if (n2 != 0) { // só mostra se não houve erro
                    exibirResultado(resultado);
                }
                break;
            case 0:
                printf("Encerrando...\n");
                break;
            default:
                printf("Opcao invalida!\n");
        }
    } while (opcao != 0);

    return 0;
}
